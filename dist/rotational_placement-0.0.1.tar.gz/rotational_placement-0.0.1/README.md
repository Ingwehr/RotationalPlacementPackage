# Rotational Placement
## About this package
This is a module intended for working with the mathematical method called rotational placement. This module offers three different experiment types with their specific uses and limitations and functions to visualize basic plots of these experiment instances. 

## Using this package 
The class Experiment is used for storing data, gathering data and retrieving this data. They are initialized with 